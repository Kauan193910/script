# Super Mario World - Leaderboard Mobile

## Descrição do Projeto

Esta é uma Leaderboard responsiva em HTML para dispositivos móveis baseada no site speedrun.com/smw. O projeto inclui todas as categorias e subcategorias principais do Super Mario World speedrunning.

## Funcionalidades Implementadas

### ✅ Categorias Disponíveis
- 96 Exit
- All Castles
- No Starworld
- 11 Exit
- 0 Exit
- 95 Exit, No Cape
- All Castles, No Cape
- No Cape, No Starworld
- 11 Exit, No Cape
- All Castles, Small Only
- No Starworld, Small Only
- Small Only
- Lunar Dragon

### ✅ Funcionalidades da Interface
- **Design Responsivo**: Otimizado para dispositivos móveis e desktop
- **Navegação por Abas**: Troca fácil entre categorias
- **Filtros Avançados**: 
  - Filtro por plataforma (SNES, SNES Classic, Wii VC, 3DS VC, Switch)
  - Busca por nome do jogador
- **Paginação**: Navegação entre páginas de resultados
- **Animações Suaves**: Transições e efeitos visuais modernos
- **Cores Temáticas**: Esquema de cores inspirado no Super Mario World

### ✅ Dados Simulados
- Dados realistas baseados no site original
- Tempos de speedrun autênticos
- Informações de plataforma e data
- Rankings com destaque para top 3 (ouro, prata, bronze)

## Arquivos do Projeto

1. **index.html** - Estrutura principal da página
2. **styles.css** - Estilos responsivos e design
3. **script.js** - Funcionalidade JavaScript
4. **leaderboard_data.json** - Estrutura de dados (exemplo)

## Como Usar

1. Abra o arquivo `index.html` em qualquer navegador web
2. Navegue entre as categorias clicando nas abas
3. Use os filtros para refinar os resultados
4. Busque por jogadores específicos
5. Navegue entre páginas usando os botões de paginação

## Limitações e Considerações

### ⚠️ Dados Estáticos
- Os dados são simulados e não se conectam ao speedrun.com em tempo real
- Para dados reais, seria necessário implementar uma API ou web scraping
- Os tempos e jogadores são baseados em dados reais mas podem não estar atualizados

### ⚠️ Funcionalidades Futuras
- Integração com API do speedrun.com (se disponível)
- Sistema de atualização automática de dados
- Mais filtros avançados (por região, por período)
- Gráficos de progressão de tempos
- Sistema de favoritos

## Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Design responsivo com Flexbox e Grid
- **JavaScript ES6+**: Funcionalidade interativa
- **Design Mobile-First**: Otimizado para dispositivos móveis

## Compatibilidade

- ✅ Chrome/Chromium
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Dispositivos móveis (iOS/Android)

## Instalação

Não é necessária instalação. Simplesmente abra o arquivo `index.html` em qualquer navegador web moderno.

