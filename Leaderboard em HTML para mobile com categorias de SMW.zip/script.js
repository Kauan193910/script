// Dados simulados das categorias e leaderboards
const leaderboardData = {
    "96-exit": [
        { rank: 1, player: "oosui", time: "1h 21m 04s 233ms", date: "11 months ago", platform: "SNES" },
        { rank: 2, player: "maibaRTA", time: "1h 21m 09s 833ms", date: "1 year ago", platform: "SNES" },
        { rank: 3, player: "Lui", time: "1h 21m 22s 817ms", date: "10 months ago", platform: "SNES" },
        { rank: 4, player: "Dr.Rokon", time: "1h 21m 34s 967ms", date: "1 year ago", platform: "SNESClassic" },
        { rank: 5, player: "Rickyye", time: "1h 21m 36s 566ms", date: "9 months ago", platform: "SNES" },
        { rank: 6, player: "Double", time: "1h 21m 40s 633ms", date: "2 months ago", platform: "SNESClassic" },
        { rank: 7, player: "hami9214", time: "1h 21m 52s 367ms", date: "9 months ago", platform: "SNES" },
        { rank: 8, player: "uenond", time: "1h 22m 17s 366ms", date: "1 year ago", platform: "SNES" },
        { rank: 9, player: "Truman", time: "1h 22m 25s 600ms", date: "6 months ago", platform: "SNES" },
        { rank: 10, player: "Umario", time: "1h 22m 27s 833ms", date: "4 years ago", platform: "SNES" }
    ],
    "all-castles": [
        { rank: 1, player: "PlayerA", time: "2h 15m 30s", date: "6 months ago", platform: "SNES" },
        { rank: 2, player: "PlayerB", time: "2h 18m 45s", date: "3 months ago", platform: "WiiVC" },
        { rank: 3, player: "PlayerC", time: "2h 22m 10s", date: "1 year ago", platform: "SNES" },
        { rank: 4, player: "PlayerD", time: "2h 25m 33s", date: "8 months ago", platform: "SNESClassic" },
        { rank: 5, player: "PlayerE", time: "2h 28m 15s", date: "2 months ago", platform: "SNES" }
    ],
    "no-starworld": [
        { rank: 1, player: "SpeedRunner1", time: "1h 45m 20s", date: "4 months ago", platform: "SNES" },
        { rank: 2, player: "SpeedRunner2", time: "1h 47m 55s", date: "7 months ago", platform: "SNES" },
        { rank: 3, player: "SpeedRunner3", time: "1h 50m 12s", date: "1 year ago", platform: "WiiVC" },
        { rank: 4, player: "SpeedRunner4", time: "1h 52m 40s", date: "5 months ago", platform: "SNESClassic" },
        { rank: 5, player: "SpeedRunner5", time: "1h 55m 08s", date: "3 months ago", platform: "SNES" }
    ],
    "11-exit": [
        { rank: 1, player: "FastRunner", time: "9m 45s", date: "2 months ago", platform: "SNES" },
        { rank: 2, player: "QuickPlayer", time: "9m 52s", date: "5 months ago", platform: "SNES" },
        { rank: 3, player: "SpeedDemon", time: "10m 03s", date: "1 year ago", platform: "SNESClassic" },
        { rank: 4, player: "RushMaster", time: "10m 15s", date: "8 months ago", platform: "SNES" },
        { rank: 5, player: "BlitzRunner", time: "10m 28s", date: "6 months ago", platform: "WiiVC" }
    ],
    "0-exit": [
        { rank: 1, player: "ZeroMaster", time: "1m 23s", date: "1 month ago", platform: "SNES" },
        { rank: 2, player: "MinimalRun", time: "1m 25s", date: "3 months ago", platform: "SNES" },
        { rank: 3, player: "ShortCut", time: "1m 28s", date: "6 months ago", platform: "SNESClassic" },
        { rank: 4, player: "QuickFinish", time: "1m 31s", date: "2 months ago", platform: "SNES" },
        { rank: 5, player: "FastExit", time: "1m 34s", date: "4 months ago", platform: "WiiVC" }
    ],
    "95-exit-no-cape": [
        { rank: 1, player: "NoCapeHero", time: "1h 35m 20s", date: "5 months ago", platform: "SNES" },
        { rank: 2, player: "CapelessRun", time: "1h 38m 45s", date: "7 months ago", platform: "SNES" },
        { rank: 3, player: "NoFlyZone", time: "1h 42m 10s", date: "1 year ago", platform: "SNESClassic" },
        { rank: 4, player: "GroundBound", time: "1h 45m 33s", date: "3 months ago", platform: "SNES" },
        { rank: 5, player: "WalkOnly", time: "1h 48m 55s", date: "8 months ago", platform: "WiiVC" }
    ],
    "all-castles-no-cape": [
        { rank: 1, player: "CastleWalker", time: "2h 45m 30s", date: "4 months ago", platform: "SNES" },
        { rank: 2, player: "FortressRun", time: "2h 50m 15s", date: "6 months ago", platform: "SNES" },
        { rank: 3, player: "TowerClimber", time: "2h 55m 40s", date: "1 year ago", platform: "SNESClassic" },
        { rank: 4, player: "KeepRunner", time: "3h 02m 20s", date: "2 months ago", platform: "SNES" },
        { rank: 5, player: "CitadelSpeed", time: "3h 08m 45s", date: "9 months ago", platform: "WiiVC" }
    ],
    "no-cape-no-starworld": [
        { rank: 1, player: "DoubleRestrict", time: "2h 15m 30s", date: "3 months ago", platform: "SNES" },
        { rank: 2, player: "HardMode", time: "2h 20m 45s", date: "5 months ago", platform: "SNES" },
        { rank: 3, player: "ChallengeRun", time: "2h 25m 10s", date: "8 months ago", platform: "SNESClassic" },
        { rank: 4, player: "DifficultPath", time: "2h 30m 55s", date: "1 year ago", platform: "SNES" },
        { rank: 5, player: "ToughRoute", time: "2h 35m 20s", date: "6 months ago", platform: "WiiVC" }
    ],
    "11-exit-no-cape": [
        { rank: 1, player: "ShortNoCape", time: "12m 30s", date: "2 months ago", platform: "SNES" },
        { rank: 2, player: "QuickWalk", time: "12m 45s", date: "4 months ago", platform: "SNES" },
        { rank: 3, player: "FastGround", time: "13m 10s", date: "7 months ago", platform: "SNESClassic" },
        { rank: 4, player: "SpeedWalk", time: "13m 25s", date: "1 year ago", platform: "SNES" },
        { rank: 5, player: "RushGround", time: "13m 40s", date: "5 months ago", platform: "WiiVC" }
    ],
    "all-castles-small-only": [
        { rank: 1, player: "TinyMario", time: "3h 15m 20s", date: "6 months ago", platform: "SNES" },
        { rank: 2, player: "SmallHero", time: "3h 22m 45s", date: "8 months ago", platform: "SNES" },
        { rank: 3, player: "MiniRun", time: "3h 28m 30s", date: "1 year ago", platform: "SNESClassic" },
        { rank: 4, player: "LittleSpeed", time: "3h 35m 15s", date: "4 months ago", platform: "SNES" },
        { rank: 5, player: "CompactRun", time: "3h 42m 50s", date: "10 months ago", platform: "WiiVC" }
    ],
    "no-starworld-small-only": [
        { rank: 1, player: "SmallNoStar", time: "2h 45m 30s", date: "3 months ago", platform: "SNES" },
        { rank: 2, player: "TinyRestrict", time: "2h 52m 15s", date: "5 months ago", platform: "SNES" },
        { rank: 3, player: "MiniChallenge", time: "2h 58m 40s", date: "8 months ago", platform: "SNESClassic" },
        { rank: 4, player: "LittleHard", time: "3h 05m 25s", date: "1 year ago", platform: "SNES" },
        { rank: 5, player: "CompactHard", time: "3h 12m 10s", date: "7 months ago", platform: "WiiVC" }
    ],
    "small-only": [
        { rank: 1, player: "OnlySmall", time: "1h 55m 20s", date: "2 months ago", platform: "SNES" },
        { rank: 2, player: "TinyOnly", time: "2h 02m 35s", date: "4 months ago", platform: "SNES" },
        { rank: 3, player: "MiniOnly", time: "2h 08m 50s", date: "6 months ago", platform: "SNESClassic" },
        { rank: 4, player: "SmallRun", time: "2h 15m 15s", date: "9 months ago", platform: "SNES" },
        { rank: 5, player: "LittleRun", time: "2h 22m 40s", date: "1 year ago", platform: "WiiVC" }
    ],
    "lunar-dragon": [
        { rank: 1, player: "DragonSlayer", time: "45m 30s", date: "1 month ago", platform: "SNES" },
        { rank: 2, player: "MoonHunter", time: "47m 15s", date: "3 months ago", platform: "SNES" },
        { rank: 3, player: "LunarMaster", time: "49m 40s", date: "5 months ago", platform: "SNESClassic" },
        { rank: 4, player: "DragonRush", time: "52m 25s", date: "8 months ago", platform: "SNES" },
        { rank: 5, player: "MoonSpeed", time: "55m 10s", date: "1 year ago", platform: "WiiVC" }
    ]
};

// Estado da aplicação
let currentCategory = '96-exit';
let currentPage = 1;
let itemsPerPage = 20;
let filteredData = [];

// Elementos DOM
const categoryTabs = document.querySelectorAll('.category-tab');
const leaderboardBody = document.getElementById('leaderboard-body');
const platformFilter = document.getElementById('platform-filter');
const searchPlayer = document.getElementById('search-player');
const prevPageBtn = document.getElementById('prev-page');
const nextPageBtn = document.getElementById('next-page');
const currentPageSpan = document.getElementById('current-page');
const totalPagesSpan = document.getElementById('total-pages');

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    loadCategory(currentCategory);
});

// Event Listeners
function initializeEventListeners() {
    // Tabs de categoria
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const category = this.dataset.category;
            switchCategory(category);
        });
    });

    // Filtros
    platformFilter.addEventListener('change', applyFilters);
    searchPlayer.addEventListener('input', debounce(applyFilters, 300));

    // Paginação
    prevPageBtn.addEventListener('click', () => changePage(currentPage - 1));
    nextPageBtn.addEventListener('click', () => changePage(currentPage + 1));
}

// Função debounce para otimizar a busca
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Trocar categoria
function switchCategory(category) {
    // Atualizar tab ativo
    categoryTabs.forEach(tab => {
        tab.classList.remove('active');
        if (tab.dataset.category === category) {
            tab.classList.add('active');
        }
    });

    currentCategory = category;
    currentPage = 1;
    loadCategory(category);
}

// Carregar dados da categoria
function loadCategory(category) {
    const data = leaderboardData[category] || [];
    filteredData = [...data];
    applyFilters();
}

// Aplicar filtros
function applyFilters() {
    const platformValue = platformFilter.value.toLowerCase();
    const searchValue = searchPlayer.value.toLowerCase();
    const originalData = leaderboardData[currentCategory] || [];

    filteredData = originalData.filter(run => {
        const matchesPlatform = !platformValue || run.platform.toLowerCase().includes(platformValue);
        const matchesPlayer = !searchValue || run.player.toLowerCase().includes(searchValue);
        return matchesPlatform && matchesPlayer;
    });

    currentPage = 1;
    updatePagination();
    renderLeaderboard();
}

// Renderizar leaderboard
function renderLeaderboard() {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageData = filteredData.slice(startIndex, endIndex);

    if (pageData.length === 0) {
        leaderboardBody.innerHTML = '<div class="loading">Nenhum resultado encontrado</div>';
        return;
    }

    leaderboardBody.innerHTML = pageData.map(run => {
        const rankClass = getRankClass(run.rank);
        return `
            <div class="leaderboard-row">
                <div class="rank-cell ${rankClass}">${run.rank}</div>
                <div class="player-cell">${run.player}</div>
                <div class="time-cell">${run.time}</div>
                <div class="date-cell">${run.date}</div>
                <div class="platform-cell">${run.platform}</div>
            </div>
        `;
    }).join('');
}

// Obter classe CSS para o ranking
function getRankClass(rank) {
    if (rank === 1) return 'gold';
    if (rank === 2) return 'silver';
    if (rank === 3) return 'bronze';
    return '';
}

// Atualizar paginação
function updatePagination() {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    
    currentPageSpan.textContent = currentPage;
    totalPagesSpan.textContent = totalPages;
    
    prevPageBtn.disabled = currentPage <= 1;
    nextPageBtn.disabled = currentPage >= totalPages;
}

// Mudar página
function changePage(newPage) {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    
    if (newPage >= 1 && newPage <= totalPages) {
        currentPage = newPage;
        updatePagination();
        renderLeaderboard();
        
        // Scroll para o topo da leaderboard
        document.querySelector('.leaderboard').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Função para simular carregamento
function showLoading() {
    leaderboardBody.innerHTML = '<div class="loading">Carregando dados...</div>';
}

// Função para lidar com erros
function showError(message) {
    leaderboardBody.innerHTML = `<div class="loading">Erro: ${message}</div>`;
}

// Função para adicionar animação aos elementos
function addRowAnimations() {
    const rows = document.querySelectorAll('.leaderboard-row');
    rows.forEach((row, index) => {
        row.style.animationDelay = `${index * 0.05}s`;
    });
}

// Observador para animações quando os elementos entram na viewport
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Aplicar observador aos elementos quando carregados
function observeElements() {
    const rows = document.querySelectorAll('.leaderboard-row');
    rows.forEach(row => {
        row.style.opacity = '0';
        row.style.transform = 'translateY(20px)';
        row.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        observer.observe(row);
    });
}

// Atualizar renderização para incluir animações
const originalRenderLeaderboard = renderLeaderboard;
renderLeaderboard = function() {
    originalRenderLeaderboard();
    setTimeout(() => {
        addRowAnimations();
        observeElements();
    }, 50);
};

